public class Video16 {
    public static void main(String[] args) {
        // lặp lại việc thực hiện một nhiệm vụ nào đó
        /*
            for(khởi tạo; điều kiện lặp; bước nhảy){
                làm cái gì đó;

            }
         */

        for(int i = 100; i >= 0; i -= 2) {
            if(i % 5 == 0){
                System.out.println(i);
            }
        }

    }
}
