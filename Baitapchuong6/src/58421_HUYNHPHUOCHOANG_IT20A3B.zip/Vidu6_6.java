public class Vidu6_6 {
    public static void main(String[] args) {
        // Khai báo một chuỗi có nội dung là "Welcome to java!"
        String chuoi = new String ("Welcome to java!" );
        System.out.println(chuoi);
    }
}