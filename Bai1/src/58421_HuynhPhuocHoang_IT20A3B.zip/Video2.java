public class Video2 {
    public static void main(String[] args) {
        System.out.println("This is second example...");
        System.out.println("This is second example...");
        System.out.println("This is second example...");
    }
}
