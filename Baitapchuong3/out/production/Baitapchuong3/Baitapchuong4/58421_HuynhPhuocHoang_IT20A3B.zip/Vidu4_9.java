package Baitapchuong4;

public class Vidu4_9 {
        public static void main(String[] args) {
            String[] cars = { "Honda", "BMW", "Ford", "Mazda" };
            System.out.println("Độ dài của mảng cars là: " + cars.length);
    }
}