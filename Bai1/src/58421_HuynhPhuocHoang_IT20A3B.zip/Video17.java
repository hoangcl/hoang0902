public class Video17 {
    public static void main(String[] args) {
        /*

           while(điều kiện lặp){
              làm cái gì đó;

           }
         */
        int i = 100;
        while (i >= 0) {
            System.out.println(i);
            i--;
        }
    }
}