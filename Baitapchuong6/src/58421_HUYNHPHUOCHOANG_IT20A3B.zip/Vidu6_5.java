public class Vidu6_5 {
    public static void main(String[] args) {
// khai báo chuỗi rỗng
        String chuoi1 = "";
// khai báo chuỗi có nội dung là "Welcome"
        String chuoi2 = "Welcome";
// hiển thị giá trị của 2 chuỗi trên ra màn hình
        System.out.println("Chuỗi rỗng có giá trị = " + chuoi1);
        System.out.println("Chuỗi 2 có giá trị = " + chuoi2);
    }
}
