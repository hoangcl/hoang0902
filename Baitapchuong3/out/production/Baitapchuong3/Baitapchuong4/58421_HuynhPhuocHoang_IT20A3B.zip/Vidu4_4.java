package Baitapchuong4;

public class Vidu4_4 {
    public static void main(String[] args) {
        int diem[][] = {{1, 2}, {3, 4}, {5, 6}};
        System.out.println("Phần tử nằm ở dòng 2 và cột 1 trong mảng diem là " +diem[2][1]);}
}
