public class Bai6 {
    public static void main(String[] args) {
        String str1 = "học java cơ bản đến nâng cao.";
        String str2 = "java cơ bản";
        System.out.println(str1.contains(str2));
    }
}
