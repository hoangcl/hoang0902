package Baitapchuong4;

public class Vidu4_3 {
    public static void main(String[] args) {
        int[] array1 = {2, 10, 3, 9, 8};
        int array2[] = new int[5];
        array2[3] = array1[2];
        System.out.println("Giá trị của phần tử thứ 3 trong mảng array2 = " + array2[3]); }
}
