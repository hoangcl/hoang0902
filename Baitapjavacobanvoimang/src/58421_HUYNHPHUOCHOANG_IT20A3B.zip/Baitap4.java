public class Baitap4 {
    public static void main(String[] args) {
        int arr[][]={{5,12,17,9,3},{13,4,8,6,1},{9,6,3,7,21}};
        for(int i=2;i<3;i++){
            for(int j=0;j<5;j++){
                System.out.print(arr[i][j]+" ");
            }
        }
    }
}