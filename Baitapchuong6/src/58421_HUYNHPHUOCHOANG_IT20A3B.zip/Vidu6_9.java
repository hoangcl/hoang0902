public class Vidu6_9 {
    public static void main(String[] args) {
        String chuoi = "Happy new year!";
        /*
        * trả về ký tự có chỉ số là 4 trong chuỗi
        *  ký tự 'H' có chỉ số là 0; nên ký tự có chỉ số 4 là ký tự 'y'
         */
        char character = chuoi.charAt(4);
        System.out.println(character);
    }
}
