public class Video5 {
    public static final double PI = 3.141592;// so PI
    public static final float G = 9.789f;

    public static void main(String[] args) {
        System.out.println(G);
        showGValue();
        showPiValue();
    }

    public static void showGValue(){
        System.out.println(G);
    }

    public static void showPiValue(){
        System.out.println(PI);
    }

}
