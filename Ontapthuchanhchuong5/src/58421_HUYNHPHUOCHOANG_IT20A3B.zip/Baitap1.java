public class Baitap1 {
    public static void main(String[] args) {
        int n = 10;
        if(n%2>=0)
        {
            System.out.println("Đây là số chẵn!");
        }
        else
        {
            System.out.println("Đây là số lẻ!");
        }
    }
}