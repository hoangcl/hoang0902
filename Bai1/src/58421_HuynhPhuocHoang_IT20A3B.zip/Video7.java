// comment trong ngon ngu lap trinh java
public class Video7 {
    public static void main(String[] args) {
        int a = -100;// gan a = 100
        int b = 255; // gan b = 255
        int sum = a + b;

        // System.out.println(sum);
    }
    /*
       comment
       tren nhieu
       dong
       khong thanh van de
       hahah...
     */

    /**
     * day la chuong trinh minh hoa de comment
     * hahaha...
     */
}


