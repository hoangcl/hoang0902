public class Video4 {
    public static void main(String[] args) {
        // your codes go here
        int firsNumber = 100;
        int secondNumber = 255;
        int sum = firsNumber + secondNumber;
        long myValue;
        boolean isTrue;
        char character = '1';
        double laiSuat;
        System.out.println("SUM OF TWO NUMBER: " + (firsNumber+secondNumber)+", "+character);
    }
}
