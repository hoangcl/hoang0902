public class Video8 {
    public static void main(String[] args) {
        System.out.println("1\t\t2\t3");
    }
}
