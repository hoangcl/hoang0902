public class Video18 {
    public static void main(String[] args) {
        /*
            do{
                làm gì đó;
            } while(điều kiện lặp);
         */
        int i = 0 ;
        while (i != 0){
            System.out.println("Hello");
        }
//        do {
//            System.out.println("Hello");
//             // i--;
//        } while (i != 0);
    }
}
