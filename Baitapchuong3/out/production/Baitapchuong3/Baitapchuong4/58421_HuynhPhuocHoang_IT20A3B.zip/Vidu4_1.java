package Baitapchuong4;

public class Vidu4_1 {
    public static void main(String[] args) {
// Khai báo và khởi tạo giá trị ban đầu cho mảng
        char[] kyTu = new char[]{'a', 'b', 'c', 'd', 'e'};
// hiển thị ký tự tại vị trí thứ 2 trong mảng
        System.out.println("Ký tự tại vị trí thứ 2 trong mảng là " + kyTu[2]);
    }
}