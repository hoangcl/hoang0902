public class Video12 {
    enum HL {YEU, TB, KHA, GIOI, XS};

    public static void main(String[] args) {
        /*

            >= 9.0:     XS
            8.0 ~ 8.9:  GIOI
            6.5 ~ 7.99: KHA
            5.0 ~ 6.49: TB
            < 0.5:      YEU
        */

        HL tb = HL.TB;

        System.out.println();
    }
}
