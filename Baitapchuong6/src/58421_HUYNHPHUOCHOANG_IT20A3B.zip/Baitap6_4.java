public class Baitap6_4 {
    public static void main(String[]args){

        int decimalNumber = 123456789;

        System.out.print("Hệ nhị phân của " + decimalNumber +" là :");

        System.out.print(Integer.toBinaryString(decimalNumber));
    }
}

